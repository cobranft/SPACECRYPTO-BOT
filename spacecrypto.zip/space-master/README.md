 Passo / Passo

Primeiro siga os passo de instalação do Python no link a seguir...
https://www.youtube.com/watch?v=e9NNyxNCF7k&t=26s
Esse link se refere ao BOT para Bomb Crypto, o qual foi usado de base para esse BOT

Apos instalar o Python, baixe o arquivo .ZIP do BOT e extraia os arquivos em uma pasta!
a dica aqui é uma pasta simples EX: no drive C crie uma pasta chamada "space" e jogue os arquivos extraidos lá!

Feito isso, abra uma aba de comandos (tecla janela do windows / escreva "cmd")
com o CMD aberto escreva os comandos a seguir sem as ""

   "cd\space"  -  nesse caso estamos entrando na pasta onde está o BOT, caso sua pasta seja diferente copie e cole o caminho no lugar do "space".

   "pip install -r requirements.txt"   -  este comando vai instalar as bibliotecas das funções do python que usamos no BOT

Agora está tudo pronto...

Para iniciar o BOT basta estar com o CMD aberto na pasta do BOT (cd\space) e digitar o seguinte comendo...

   "python space.py"


OBRIGADO, e caso queira contribuir agradecemos...

	BUSD - BNB - SPE - SPG - BCOIN

MEtamask = 0x97993028F185A27aa59505B15a7Dd8D33B4CC1f3


DICA --- Tela do jogo bem pequena (22,5cm / 17,5 cm)  (Monitor 1920/1080)